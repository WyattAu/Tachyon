# Research Notes\n\n## Sources\n- [Link 1](https://example.com)\n- [Link 2](https://example.org)\n\n## Summary\nKey findings from research.
