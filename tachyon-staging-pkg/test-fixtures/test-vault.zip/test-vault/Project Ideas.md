# Project Ideas\n\n## Ideas\n- [[Meeting Notes]]\n- [[Daily Notes/2026-06-10]]\n- New feature concept
