# Meeting Notes\n\n## Attendees\n- Alice\n- Bob\n\n## Agenda\n1. Review E2E tests\n2. Plan next sprint
